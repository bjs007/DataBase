# ifndef CONSTANTS_H_INCLUDED
#define CONSTANTS_H_INCLUDED
/**************Start*******************************************************************/
#define MAX_FILES 1000  //Maximum number of permissible files
/**************************************************************************************/
#endif// CONSTANTS_H_INCLUDED
